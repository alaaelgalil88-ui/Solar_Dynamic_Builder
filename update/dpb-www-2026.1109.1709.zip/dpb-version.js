window.DPB_WEB_VERSION='2026.1109.1709';window.DPB_UPDATE_URL='https://alaaelgalil88-ui.github.io/Solar_Dynamic_Builder/update/';

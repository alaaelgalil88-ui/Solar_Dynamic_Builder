window.DPB_WEB_VERSION='2026.1031.445';window.DPB_UPDATE_URL='https://alaaelgalil88-ui.github.io/Solar_Dynamic_Builder/update/';
